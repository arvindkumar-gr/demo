//
//  ViewController.swift
//  WheatherApp
//
//  Created by nareshnaidu on 26/09/18.
//  Copyright © 2018 nareshchoudhary. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var temperature: UILabel!
    
    var forecastData = [WheatherData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        WheatherData.forecast(withLocation: "37.8267,-122.4233") { (results:[WheatherData]) in
            for result in results {
                print("\(result)")
            }
        }
    }
    
}


