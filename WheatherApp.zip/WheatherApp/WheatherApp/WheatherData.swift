//
//  WheatherData.swift
//  WheatherApp
//
//  Created by nareshnaidu on 26/09/18.
//  Copyright © 2018 nareshchoudhary. All rights reserved.
//

import Foundation
import CoreLocation

struct WheatherData {
    let city: String
    let icon: String
    let temperature: Double
    
    enum SerilizationError: Error {
        case missing(String)
        case invalid(String, Any)
        
    }
    
    init(json: [String:Any]) throws {
        guard let city = json["city"] as? String else { throw SerilizationError.missing("city is missing")}
        guard let icon = json["icon"] as? String else { throw SerilizationError.missing(" icon is missing") }
        guard let temperature = json["temperatureMax"] as? Double else { throw SerilizationError.missing(" temp is missing") }
        
        self.city = city
        self.icon = icon
        self.temperature = temperature
    }
    
    static let basePath = "https://samples.openweathermap.org/data/2.5/forecast?id=524901&appid=b1b15e88fa797225412429c1c50c122a1"
    
    static func forecast (withLocation location:String, completion: @escaping ([WheatherData]) -> ()) {
        
        let url = basePath + location
        let request = URLRequest(url: URL(string: url)!)
        
        let task = URLSession.shared.dataTask(with: request) { (data:Data?, response:URLResponse?, error:Error?) in
            
            var forecastArray:[WheatherData] = []
            
            if let data = data {
                print(data)
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any] {
                        print(json)
                        if let dailyForecasts = json["clouds"] as? [String:Any] {
                            if let dailyData = dailyForecasts["main"] as? [[String:Any]] {
                                
                                for dataPoint in dailyData {
                                    if let weatherObject = try? WheatherData(json: dataPoint) {
                                        forecastArray.append(weatherObject)
                                    }
                                }
                            }
                        }
                        
                    }
                }catch {
                    print(error.localizedDescription)
                }
                
                completion(forecastArray)
                
            }
            
        }
        
        task.resume()
        
    }
    
    
}
